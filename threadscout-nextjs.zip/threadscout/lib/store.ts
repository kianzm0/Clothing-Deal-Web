"use client";
import { useEffect, useState } from "react";
import { DEFAULT_PREFERENCES, Preferences } from "./types";

// Client-side persistence layer. Mirrors the original static site's use
// of browser storage. In Phase 2 this gets a server-backed twin behind
// the same hook names once auth (Supabase/Clerk/Auth.js) lands, so
// components never need to know which backend they're talking to.

const WATCHLIST_KEY = "threadscout:watchlist";
const PREFS_KEY = "threadscout:preferences";

function readJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function useWatchlist() {
  const [ids, setIds] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setIds(readJSON<string[]>(WATCHLIST_KEY, []));
    setHydrated(true);
  }, []);

  function toggle(id: string) {
    setIds((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      writeJSON(WATCHLIST_KEY, next);
      return next;
    });
  }

  return { ids, toggle, hydrated };
}

export function usePreferences() {
  const [prefs, setPrefs] = useState<Preferences>(DEFAULT_PREFERENCES);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setPrefs(readJSON<Preferences>(PREFS_KEY, DEFAULT_PREFERENCES));
    setHydrated(true);
  }, []);

  function update(next: Partial<Preferences>) {
    setPrefs((prev) => {
      const merged = { ...prev, ...next };
      writeJSON(PREFS_KEY, merged);
      return merged;
    });
  }

  return { prefs, update, hydrated };
}
