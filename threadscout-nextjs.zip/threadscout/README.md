# ThreadScout — Phase 2 (Next.js + TypeScript)

Rebuild of the static MVP from your original repo, using the exact
architecture your own README called for. No behavior changed, no
placeholder pages — every feature from the static version works
here, typed and componentized.

## Run it

```
npm install
npm run dev
```

Open http://localhost:3000

## What changed vs. the static MVP

- All data flows through `lib/repository.ts`. That is the ONLY file
  you touch when you plug in Postgres (Prisma/Drizzle) — pages call
  `getAllProducts()` / `getProductById()`, never the raw array.
- `lib/store.ts` holds the watchlist + preferences hooks. Same
  localStorage approach as before, but typed, and structured so a
  server-backed version (once you add Supabase/Clerk/Auth.js) can
  replace the internals without touching any component.
- `lib/recommend.ts` is your rule-based scoring, ported 1:1.
- `lib/pricing.ts` centralizes "best offer", discount %, and
  freshness math that both the browse grid and the detail page use.

## File map

- `app/page.tsx` — browse/search/filter/sort (was index.html)
- `app/product/[id]/page.tsx` — offer comparison table
- `app/watchlist/page.tsx` — saved items
- `app/preferences/page.tsx` — size/brand/color/budget/discount prefs
- `lib/data.ts` — seeded catalog (swap target for Phase 3 DB work)
- `lib/repository.ts` — the data-access seam for Phase 3
- `lib/types.ts`, `lib/pricing.ts`, `lib/recommend.ts`, `lib/store.ts`

## Phase 3: Postgres + Prisma (done)

`lib/repository.ts` now queries Postgres through Prisma instead of
the in-memory array in `lib/data.ts`. That file still exists — it's
only used by `prisma/seed.ts` now, to populate the database.

### Setup

1. Get a Postgres instance. Fastest options: a free one on
   [Neon](https://neon.tech) or [Supabase](https://supabase.com), or
   `docker run -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres`
   locally.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` to your
   connection string.
3. `npx prisma generate` — generates the typed client `lib/prisma.ts`
   imports from. Do this before `npm run dev` or `npm run build`,
   and again any time you edit `prisma/schema.prisma`.
4. `npx prisma migrate dev --name init` — creates the `products` and
   `offers` tables.
5. `npx tsx prisma/seed.ts` — loads the demo catalog into the DB.
6. `npm run dev` — the site now reads from Postgres.

## Phase 4: Auth (done)

Email/password auth via NextAuth v4 (Auth.js), Credentials provider,
JWT sessions — no third-party auth service or OAuth app registration
needed. A `User` model was added to `prisma/schema.prisma`.

### Setup (in addition to the Phase 3 steps)

1. Add to `.env`: `NEXTAUTH_SECRET` (generate with
   `openssl rand -base64 32`) and `NEXTAUTH_URL="http://localhost:3000"`.
2. Run `npx prisma migrate dev --name add_users` to create the
   `users` table.
3. Visit `/signup` to create an account, or `/login` to sign in.
   The nav bar shows your email and a sign-out link once authenticated.

### What's NOT done yet

Watchlist and preferences are still per-browser (localStorage), not
per-account — signing in doesn't yet move your saved items to the
database. That's the natural next step now that `User` exists: add
`Watchlist` and `Preference` tables tied to `userId`, and swap
`lib/store.ts`'s localStorage calls for API routes that check the
session. Worth doing before real offer feeds, since "my saved
deals" is more valuable once it follows the user across devices.

## Next up (Phase 5+, per your original roadmap)

1. Move watchlist/preferences from localStorage to per-user DB rows (see above)
2. Real offers via affiliate feeds or retailer APIs (drop the scraping idea — ToS risk)
3. Server-side event tracking (searches, saves, filters, outbound clicks)
4. Background jobs for price refresh + price-drop alerts
