"use client";
import Link from "next/link";
import { Product } from "@/lib/types";
import { bestOffer, discountPct } from "@/lib/pricing";
import { useWatchlist } from "@/lib/store";

export default function ProductCard({ product }: { product: Product }) {
  const offer = bestOffer(product);
  const discount = discountPct(offer);
  const { ids, toggle, hydrated } = useWatchlist();
  const saved = hydrated && ids.includes(product.id);

  return (
    <div className="group relative rounded-lg border border-gray-200 bg-white p-4 shadow-sm transition hover:shadow-md">
      <button
        onClick={() => toggle(product.id)}
        aria-label={saved ? "Remove from watchlist" : "Save to watchlist"}
        className={`absolute right-3 top-3 rounded-full border px-2 py-1 text-xs font-medium ${
          saved ? "border-brand-500 bg-brand-50 text-brand-700" : "border-gray-300 text-gray-500"
        }`}
      >
        {saved ? "Saved" : "Save"}
      </button>
      <Link href={`/product/${product.id}`}>
        <div className="mb-3 flex h-32 items-center justify-center rounded bg-gray-100 text-3xl">
          👕
        </div>
        <p className="text-xs uppercase text-gray-500">{product.brand}</p>
        <h3 className="font-semibold">{product.name}</h3>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-lg font-bold">${offer.price}</span>
          {discount > 0 && (
            <>
              <span className="text-sm text-gray-400 line-through">${offer.originalPrice}</span>
              <span className="text-sm font-medium text-emerald-600">-{discount}%</span>
            </>
          )}
        </div>
        <p className="mt-1 text-xs text-gray-500">Best at {offer.store}</p>
      </Link>
    </div>
  );
}
