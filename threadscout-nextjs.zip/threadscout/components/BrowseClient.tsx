"use client";
import { useMemo, useState } from "react";
import { Product } from "@/lib/types";
import { bestOffer, discountPct, daysSinceUpdate } from "@/lib/pricing";
import { scoreProduct } from "@/lib/recommend";
import { usePreferences } from "@/lib/store";
import FilterBar, { DEFAULT_FILTERS, Filters } from "./FilterBar";
import ProductCard from "./ProductCard";

export default function BrowseClient({ products }: { products: Product[] }) {
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const { prefs } = usePreferences();

  const brands = useMemo(
    () => Array.from(new Set(products.map((p) => p.brand))).sort(),
    [products]
  );

  const results = useMemo(() => {
    let list = products.filter((p) => {
      const offer = bestOffer(p);
      if (filters.category !== "all" && p.category !== filters.category) return false;
      if (filters.brand !== "all" && p.brand !== filters.brand) return false;
      if (offer.price > filters.maxPrice) return false;
      if (discountPct(offer) < filters.minDiscount) return false;
      return true;
    });

    switch (filters.sort) {
      case "lowest-price":
        list = [...list].sort((a, b) => bestOffer(a).price - bestOffer(b).price);
        break;
      case "biggest-discount":
        list = [...list].sort((a, b) => discountPct(bestOffer(b)) - discountPct(bestOffer(a)));
        break;
      case "freshest":
        list = [...list].sort((a, b) => daysSinceUpdate(bestOffer(a)) - daysSinceUpdate(bestOffer(b)));
        break;
      default:
        list = [...list].sort((a, b) => scoreProduct(b, prefs) - scoreProduct(a, prefs));
    }
    return list;
  }, [products, filters, prefs]);

  return (
    <div>
      <FilterBar filters={filters} brands={brands} onChange={setFilters} />
      <p className="mb-3 text-sm text-gray-500">{results.length} results</p>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {results.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
