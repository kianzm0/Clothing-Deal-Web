import { getProductById } from "@/lib/repository";
import { discountPct, daysSinceUpdate } from "@/lib/pricing";
import { notFound } from "next/navigation";

export default async function ProductPage({ params }: { params: { id: string } }) {
  const product = await getProductById(params.id);
  if (!product) return notFound();

  const offers = [...product.offers].sort((a, b) => a.price + a.shippingCost - (b.price + b.shippingCost));

  return (
    <div>
      <p className="text-xs uppercase text-gray-500">{product.brand}</p>
      <h1 className="mb-1 text-2xl font-bold">{product.name}</h1>
      <p className="mb-6 text-sm text-gray-500">
        Sizes: {product.sizes.join(", ")} · Colors: {product.colors.join(", ")}
      </p>

      <div className="mb-3 flex h-48 items-center justify-center rounded bg-gray-100 text-5xl">
        👕
      </div>

      <h2 className="mb-2 font-semibold">Compare offers</h2>
      <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left text-gray-500">
            <tr>
              <th className="px-4 py-2">Store</th>
              <th className="px-4 py-2">Price</th>
              <th className="px-4 py-2">Shipping</th>
              <th className="px-4 py-2">Sizes in stock</th>
              <th className="px-4 py-2">Updated</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {offers.map((offer, i) => (
              <tr key={offer.store} className={i === 0 ? "bg-emerald-50" : "border-t border-gray-100"}>
                <td className="px-4 py-3 font-medium">{offer.store}</td>
                <td className="px-4 py-3">
                  ${offer.price}
                  {discountPct(offer) > 0 && (
                    <span className="ml-2 text-xs font-medium text-emerald-600">-{discountPct(offer)}%</span>
                  )}
                </td>
                <td className="px-4 py-3">{offer.shippingCost === 0 ? "Free" : `$${offer.shippingCost}`}</td>
                <td className="px-4 py-3">{offer.sizesInStock.join(", ")}</td>
                <td className="px-4 py-3 text-gray-500">{daysSinceUpdate(offer)}d ago</td>
                <td className="px-4 py-3">
                  <a href={offer.url} className="text-brand-600 hover:underline">View →</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
